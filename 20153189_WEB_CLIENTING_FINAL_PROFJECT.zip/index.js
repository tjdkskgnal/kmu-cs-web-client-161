var input = 0;
$(document).keypress(function(){
	switch(event.keyCode){
		case 32:
			newwin = window.open("index.html", "" ,"width=500, height=500");
			break;
		case 81:
		case 113:
			window.resizeBy(0,50);
			break;
		case 87:
		case 119:
			window.resizeBy(0,-50);
			break;
		case 69:
		case 101:
			window.resizeBy(50,0);
			break;
		case 82:
		case 114:
			window.resizeBy(-50,0);
			break;
	}
})
function resizeWin(x){

	x.resizeBy(200,200);
}

$('#explain').dblclick(function(){
	$('#explain_table').slideToggle(2000);
})

$('ul').mouseenter(function(){
	$(this).html(' <li><a href="#foundation">Good<br>Neighbors</a></li><li><a href="#explain_element">사업안내</a></li><li><a href="#help_element">후원하기</a></li><li><a href="#way_element">찾아오시는 길</a></li>')
	$(this).attr('style', 'width:8%');

})

$('video').dblclick(function(){
	$(this).animate({height:"70%", width:"100%", top:"0px"}, 2000);
})

$('ul').mouseleave(function(){
	$(this).html('');
	$(this).attr('style', 'width:0.01%');
})

$('input').focus(function(){
	$(this).next('span').removeAttr('hidden');
});

$('input').blur(function(){
	$(this).next('span').attr('hidden', 'hidden');
});

$('#Global mark').click(function(){
	$(this).text('Global');
})

$('#Child mark').click(function(){
	$(this).text('Child');
})

$('#Idea mark').click(function(){
	$(this).text('Idea');
})

$('#Accountability mark').click(function(){
	$(this).text('Accountability');
})

$('#Innovation mark').click(function(){
	$(this).text('Innovation');
})

$('#Global').mouseenter(function(){
	$('#Global p').attr('style', 'color:black')

})
$('#Global').mouseleave(function(){
	$('#Global p').attr('style', 'color:#cccccc')
})

$('#Child').mouseenter(function(){
	$('#Child p').attr('style', 'color:black')
})
$('#Child').mouseleave(function(){
	$('#Child p').attr('style', 'color:#cccccc')
})

$('#Idea').mouseenter(function(){
	$('#Idea p').attr('style', 'color:black')
})
$('#Idea').mouseleave(function(){
	$('#Idea p').attr('style', 'color:#cccccc')
})

$('#Accountability').mouseenter(function(){
	$('#Accountability p').attr('style', 'color:black')
})
$('#Accountability').mouseleave(function(){
	$('#Accountability p').attr('style', 'color:#cccccc')
})

$('#Innovation').mouseenter(function(){
	$('#Innovation p').attr('style', 'color:black')
})
$('#Innovation').mouseleave(function(){
	$('#Innovation p').attr('style', 'color:#cccccc')
})

$('h3').dblclick(function(){
	switch(input%8){
	case 0: 
		$(this).attr('style', 'color:red')
		input++;
		break;
	case 1:
		$(this).attr('style', 'color:orange')
		input++;
		break;
	case 2:
		$(this).attr('style', 'color:yellow');
		input++;
		break;
	case 3:
		$(this).attr('style', 'color:green');
		input++;
		break;
	case 4:
		$(this).attr('style', 'color:blue');
		input++;
		break;
	case 5:
		$(this).attr('style', 'color:navy');
		input++;
		break;
	case 6:
		$(this).attr('style', 'color:purple');
		input++;
		break;
	default:
		$(this).attr('style', 'color:black');
		input++;
	}
})